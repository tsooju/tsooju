# class_mission1.py
# 클래스 실습 문제

class Book:
    __title = "noname"
    __author = "noname"
    __price = 0
    __tex = 0.05

    def __init__(self):  # 기본 생성자, 수정 가능
        print("Book 클래스 기본생성자 작동 됨")

    def __del__(self):
        print("인스턴스 메모리에서 제거됨. ")

    def info(self):
        return f"도서제목 : {}, 저자 : {}, {}원, 부사게 : {}"

    def set_title(self, title):
        self.__title = title

    def set_author(self, author):
        self.__author = author


    def set_price(self, pridce):
        self.__price = price

    def set_tex(self, tex):
        self.__tex = tex

    def get_title(self, title):
        self.__title = title

bref = Book()

print(bref.info())
print(Book.info(bref))

bref.set_title("파이썬 이해")
bref.set_author("홍길동")
bref.set_price(35000)
bref.set_tex(0.1)

print(bref.info())

bookPrice = bref.get_price() + (bref.get_price() * bref.get_tex())
print("도서금액 : ", bookPrice)
















