# class_oop.py
# 객체지향 프로그래밍(OOP) 적용

# 객체지향 프로그래밍에서의 클래스 멤버는
# 필드(멤버변수), 메소드(멤버함수), 생성자(constructor), 소멸자(destructor)

# OOP에 사용되는 기술(3대 특징)도 적용해야 함.

"""
1. 캡슐화(encapsulation)
2. 상속(inherintance)
3. 다형성(polymorphism)
코드에 반드시 사용되어야 하는 기술이다.
"""

"""
OOP 적용기술 1 : 캡슐화(encapsulation)   가장 중요한 기술이다. 

목적 : 데이터 보호가 목적이다. 필드의 접근 제한을 둠. 
** 팔드에 접근제한자(access modifier)를 사용하게 된다. 이것이 캡슐화다. 

기본 3 가지 접근 제한자 있다 : 
접근에 제한을 두는 단어 : 1. public(공개), 2. private(비공개), 3. protected(상속시 후손한테만 공개)
파이선에서는 이러를 단어를 사용하지 않는다. 

"""
# 파이선에서는 접근제한자 없(제공 안 됨)다.
# 파이선에서는 기본적으로 모든 멤버는 public(공개)임.

# public 상태는 클래스 밖에서 멤버(필드, 메소드)들을 사용할 수 있다는 의미임.
# 레퍼런스.필드명, 레퍼런스.메소드명()
# 클래스명.필드명, 클래스명.메소드명(레퍼런스)




# private : 클래스 밖에서 사용 못한다. 클래스 안에서만 사용 가능. 이것이 private이다.
# private : 캡슐화란 필ㄷ를 비공개 처리하는 것(필수)이다. 메소드는 공개(선택)함. how to use on python by private ?

# 파이선에서 클래스 멤버를 비공개(private) 처리 하려면 :
# 필드명이나 메소드명 앞에 "_"(доогуур зураас 2ш бичих хэрэгтэй. тэгвэл бусдад харагдахгүй гэсэн юм)

class PClass:
    __num = 10  # private (비공개) 필드가 된다.

    def set_num(self, n):       # public (공개) 매소드
        self.__num = n          # 값 변경하는 메소드가 만들어짐.

    def get_num(self):          # public (공개) 메소드
        return self.__num

# 클래스 멤버 사용
# print("PClass 의 __num 값 확인 : ", PClass.__num)   # 비공개 했기 때문에 밖에서 사용을 못한다.

pref = PClass()
# print("pref 를 통한 참조 접근 : ", pref.__num)     # 비공개 했기 때문에 밖에서 사용을 못한다.

print("인스턴스 안의 __num 값 : ", pref.get_num())    # 매소드는 공개로 되어 있기 때문에 사용을 할 수 있다.

# 파이선의 생성자는 누구 : 생성자(constructor) 함수의 일종이다.
# 객체 인스턴스가 메모리에 할당될 때, 필드값 초기화가 목적인 함수임
# 생성자를 작성하지 않으면, 내부에서 기본생성자가 작동됨.
# 생성자를 작성하고 싶으면 : __init__ 라고 표기를 해야 한다.
# 파이선에서는 생성자는 오버로딩(overloading) 할 수 없음.
"""
def __init__(self, 필요한 매개변수 선언):
    self.필드명 = 매개변수 
    
생성자 사용 : 
레퍼런스 = 클래스명(전달값)
"""

# 소멸자 함수(Destructor) : 객체가 소멸될(인스턴스가 메모리에서 제거될 때) 때 자동 실행되는 함수임
# 클래스 안에 직접 작성한다면 , __del__ 로 정의함.

# 해당 객체 관련 메모리나 자원들의 공유 설정, 점유 설정 등을 해제할 때 사용

"""
def __del__(self):
    소멸시 처리내용 코드 작성 
"""

class Var:
    __num = 100

    def __init__(self, n):
        self.__num = n   # 객체가 메모리에 할당 (생성)될 때 값 바꿈

    def __del__(self):
        print("인스턴스 메모리에서 제거됨. ", id(self))   # self 위치가 없어졌다는 뜻

    def get_num(self):
        return self.__num

    def set_num(self, n):
        self.__num = n


# 클래스 객체 생성

v1 = Var(77)   # 할당 한 객체의 필드 값을 77로 바궈라 란 뜻
v2 = Var(88)

print("v1 : ", v1.get_num())
print("v2 : ", v2.get_num())
# 프로그램이 종료될 때 소멸자가 자동 실행됨.


# 키보드로 입력 받을시
v1.set_num(int(input("v1의 참조하는 인스턴스의 변경할 필드값 : ")))
print("v1 : ", v1.get_num())
v2.set_num(int(input("v2의 참조하는 인스턴스의 변경할 필드값 : ")))
print("v2 : ", v2.get_num())



# ------------------------------------------------------------------------------------
# 정적 메소드 (static method)

# 정적(static)메모리에 따로 기록되는 메소드다.
# 정적 메모리를 클래스 공간이다라고도 한다.
# 정적 메모리(static)애 로딩된 소스 코드들이 기록됨 (method area)
# 클래스영역 (클래스 이름 공간)이라고도 한다.
# 메소드 작성시 메소드 이름위에 장식자(decorator)를 표시하면 됨.
# @staticmethod
# 객체 인스턴스와 분리 됨 => self가 없는 메소드임.

class C:
    def ham(self, x, y):   # 동적 메모리에 할당됨. self 매개변수 있음.
        print("instance method : ", x , y)  # 주소로 객체와 연결됨.


class D:
    @staticmethod
    def spam(x, y):      # self가 없다는 것이 정적의 특징이다. 정적 메모리에 할당됨. 매소드가 객체와 연결될 수 없음
        print("static | class method : ", x, y)
    # 정적 메모리와 동적 메모리 간에는 주소 참조 못 함.

# static method 은 사용시 객체레퍼런스(인스턴스의 주소) 없이 실행함.
# 클래스명.메소드(전달값, 전달값)

D.spam(10, 20)
dref = D()
dref.spam(10, 20)   # static method 는 instance method 처럼 사용해도 된다.




# instance method 사용 :
ref = C()
ref.ham(11, 22)
C.ham(ref,  11, 22)


# 연산자 오버로딩 (operator overloading)  # 같은 거를 여러번 만들어준다. 중복 작성. 있는데 또 만든다는 것이다.
# 연산자는 : 값 계산의 사용되는 기호 문자를 말한다.
# c++, python 에서는 기존 값 계산에 사용되는 연산자에다가
# 클래스 객체에 대한 연산으로 새로운 의미를 정의하는 것.

"""
객체 + 값 : __add__(self, value): return self.속성 + value 
객체 - 값 : __sub__(self, value): return self.속성 - value 
객체 * 값 : __mul__(self, value): return self.속성 * value
객체 / 값 : __truediv__(self, value): return self.속성 / value
객체 > 값 : __gt__(self, value): return self.속성 > value
객체 >= 값 : __ge__(self, value): return self.속성 >= value
객체 < 값 : __it__(self, value): return self.속성 < value
객체 <= 값 : __le__(self, value): return self.속성 <= value
객체 == 값 : __eq__(self, value): return self.속성 == value
객체 != 값 : __ne__(self, value): return self.속성 != value


# 시퀀스나 멥 타입으로 오버라이딩 할 수 있음.


 
"""


class OOP:
    __num = 0

    def __init__(self, num):
        self.__num = num


    # + 연산자 메소드 오버도딩 작성
    def __add__(self, other):
        return self.__num + other

    # - 연산자 메소드 오버도딩 작성
    def __sub__(self, other):
        return self.__num - other

    # * 연산자 메소드 오버도딩 작성
    def __mul__(self, other):
        return self.__num * other

    # / 연산자 메소드 오버도딩 작성
    def __truediv__(self, other):
        return self.__num / other



    def get_num(self):
        return self.__num



# 클래스 객체 생성과 연산자 확인

ref = OOP(100)
print("ref -> __num : ", ref.get_num())

# overloading 된 연산자 메소드는  일반 연산자로 사용함.

print("+ : ", ref + 30)
print("- : ", ref - 30)
print("* : ", ref * 3)
print("/ : ", ref / 3)













