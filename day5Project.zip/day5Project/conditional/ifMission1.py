# conditionl\\ifMission1.py
# if 문 실습문제

def practice1():
    num1 = int(input("정수 입력 하세요 : "))
    num2 = int(input("정수 입력 하세요 : "))

    if(num1 > 0 and num2 > 0):
        sum = num1 + num2
        sub = num1 - num2
        mul = num1 * num2
        div = num1 // num2
        mod = num1 % num2


        print("{} + {} = {}".format(num1, num2, sum))
        print("{} - {} = {}".format(num1, num2, sub))
        print("{} * {} = {}".format(num1, num2, mul))
        print("{} // {} = {}".format(num1, num2, div))
        print("{} % {} = {}".format(num1, num2, mod))
