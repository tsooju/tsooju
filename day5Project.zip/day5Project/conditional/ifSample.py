# conditioal\\ifSample.py  => 경로 표시
# conditional.ifSample.py  => module로 경로 표시

# 제어문 : 조건문, if문 테스트

# 코맨트가 길어질 시 """ 개를 써준다.
"""
제어문(처리문) : 다른 말로 ligoc라고 한다.
=> 준비된 값의 계산 처리를 위해 사용되는 처리문장이다.
=> 제어문 종류 : 1. 조건문, 2. 반복문, 3. 분기문(크게(따로) 많이 사용 안한다. )

=> 조건문 : 조건을 제시해서 결과가 참(True) | 거짓(False)이 나오게끔
        해서 결과에 따라서 처리내용의 다르게 작동되게 하는 구문. 조건을 제시하는 것이 중요하다.

=> 반복(loop)문 : 반복되는 구간을 루프(loop)라고 한다.
        반복 실행할 구문(들)을 원하는 횟수 만큼 또는 종료조건이 될 때가지
        반복 실행되게 작성하는 구문을 반복문라고 한다. - for 문, while 문 두까지로 말할수 있다.

=> 분기문 : 실행 순서를 중간 생략시키거나, 강제로 종료시키는 구문.
        - continue 문, break 문 라고 한다.
"""

# 조건문에서는 조건식(표현식 : expression) 작성 중요함.

# 조건표현식(계산식)은 반드시 결과가 참 | 거짓 나오게끔 작성해야 함.
# 참 | 거짓의 값을 만드는 연산자(element)를 사용함 : 비교, 논리 연잔자
# if 문, if ~ else 문, if ~ elseif 문 다 따로 사용할 수 있음.

"""
if 조건식:
    조건식의 결과가 참(True)일때 실행할 구문 (* 반드시 들여쓰기함 *)
    실행할 구문은 여러 개여도 됨. 대신 꼭 들여쓰기함. 
    
    
if (조건식):  => 조건식응 ()로 묶어서 작성해도 됨.  # 두까지로 사용할 수 있음.
    결과가 참일때 실행할 코드 구문들
     
"""


# 조건문 작성형식 1 : if 만 사용한 조건문.

def iftest():
    # if (True): # True 이면 아래의 내용이 실행됨
    if (False):  # => if 가 False 이면 아래의 내용은 실행되지 않음.
        print("if 조건이 참이면 실행됩니다.")
            # print("여러 개의 구문을 순서대로 작동합니다.") # if 밑에서 처리를 안하면 IndentationError가 발생한다.

    print("if 문이 종료되고 나서 실행할 구문입니다. ")

    # if(True):
    # print("test")   => IndentationError 발생

# if 의 조건식은 주로 값을 확인하고나, 값이 원하는 범위 안의 값인지 확인.
# 입력받은 정수숫자가 1 이냐?
def iftest2():
    num = int(input("정수 숫자 입력 : "))
    if(num == 1): # 정수 숫자 1 과 같으냐란 뜻, num 값이 1 일때만 작동시켜라란 것이다.
        print("num : ", num)

# 정수를 입력받아서, 짝수인지 확인(2의 배 수)
# 짝수 : 2의 배수를 말함 : 2로 나눈 나머지가 0 인 수
# 홀수 : 2의 배수가 아닌 수 : 2로 나눈 나머지가 1 인 수

def testEven():
    num = int(input("정수 하나 입력 : "))
    if(num % 2 == 0):  # 2로 나눈 나머지 값
        print(f"입력받은 {num}은 짝수이다.")


#  조건문 작성형식 2 : if ~ else 문
"""
if(조건식): 
    참일 때 처리내용 
else: 
    거짓일때 처리내용 (항상 위의 if조건의 반대 뜻을 가진다.)
"""

def testEven2():
    num = int(input("정수 하나 입력 : "))
    if(num % 2 == 0):  # 2로 나눈 나머지 값
        print(f"입력받은 {num}은 짝수이다.")
    else:  # num % 2 == 0 또는 num % 2 != 0
        print(f"입력받은 {num}은 홀수이다.")

# 정수를 입력받아서, 1부터 100사이의 값이면 입력값의 제곱을 출력
# 해당 범위의 값이 아니면 "1~100 사이의 값만 입력하세요." 출력
# 1 <=  입력받은 값  <=  100 (컴퓨터에서는 이렇게 사용할 수가 없다.)
# 대신 1 <= 입력받은 값 and 입력받은 값 <= 100  (# 모두 True 일 때 사용하는 연산자는 and 다.)

def test_ifelse():
    num = int(input("정수 입력 : "))
    if(num >= 1 and num <= 100):
        print(f"{num} 의 제곱은 {num ** 2}")

    else:
        print("1이상 100이하의 값만 입력하세요.")

# in 연산자(element) = 자바나 C언어에는 없다. : 군집자료형(list, tuple, set, str)에 사용함.
# 변수 또는 값 in 군집자료형변수 :
# x in s  => s 안에 x 가 있느냐?  => 있으면 True, 없으면 False
# x not in s : s 안에 x 가 없느냐? => 없으면 True, 있으면 False

def test_in():
    print(2 in [1, 2, 3])  # True
    print(1 not in (1, 2, 3)) # False
    print("a" in "abcdef") # True
    print("a" not in ("a", "b", "c")) # False

# 결재수단 중에 "money" 가 있으면, "5000원을 현급지불하셨습니다." 출력
# 없으면 "다른 결재 수단을 선택하세요." 출력

def checkPayment():

    payment = input("결재 수단을 선택하세요 : ")
    price = 5000

    if("money" in payment):
        print(f"{price}원을 현금 지불하셨습니다.")

    elif("card" in payment):
        print(f"{price}원을 카드 지불하셨습니다.")

    elif ("phone" in payment):
        print(f"{price}원을 모바일 지불하셨습니다.")

    else:
        print("다른 결재 수단을 선택하세요.")


# 조건문 작성방식 3 : 다중 if 문
# if elif elif elif식으로 하는 것인데 마지막엔 else 가질 수 있고 , 안 가질 수 있다. else는 모든 조건이 아니다란 뜻

def checkPayment2():

    payment = ["결재수단", "card", "money", "phone", "zeropay"]

    print("============= 결재 수단 ==============")
    print("1. 카드")
    print("2. 현금")
    print("3. 핸드폰")
    print("4. 제로페이")
    no = int(input("결재수단에 대한 번호 입력 : "))

    price = 5000

    if(no == 1): # no가 1이냐?
        print(f"{price}원을 {payment[1]}로 지불하셨습니다.")

    elif(no == 2): # no 가 1이 아니고 2냐?
        print(f"{price}원을 {payment[2]}로 지불하셨습니다.")

    elif(no == 3): # no 가 1, 2가 아니고 3냐?
        print(f"{price}원을 {payment[3]}로 지불하셨습니다.")

    elif(no == 4): # no 가 1, 2, 3이 아니고 4냐?
        print(f"{price}원을 {payment[4]}로 지불하셨습니다.")

    else: # if 문은 다 아니면.
        print("다른 결재 수단을 선택하세요.")


# 중첩 조건문 : if 문 안에서 if 문 사용.
def multi_if():
    n1 = 10
    n2 = 20

    if n1 == 10:
        print(f"n1 : {n1}")
        if n2 == 20:
            print(f"n2 : {n2}")
        else:
            print("n2가 20이 아니다.")
    else:
        print("n1은 10이 아니다.")

# 간단 if 문 :
# 변수 = 참일 때 실행내용 if(가운대) 조건식 거짓일 때 실행내용


def shortCondition():
    a = 1
    message = "a is 1" if(a == 1) else "a is not 1" # True이면 str을 message에 입력한다.
    print(message)

def shortCondition2():
    score = int(input("점수 입력 : "))
    result = "합격" if(score >= 60) else "불합격"
    print(result)








