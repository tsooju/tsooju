# conditional\\ifelse_mission3.py
# conditional.ifelse_mission3

def practice3():
    tno = input("수험번호 : ")
    database = int(input("데이터베이스 : "))
    programm = int(input("프로그램언어 : "))
    software = int(input("소트트웨어공학 : "))

    tot = database + programm + software
    avg = tot // 3

    if(database >= 40 and programm >= 40 and software >= 40 and avg > 60):
        print(f"수험번호 : {tno} 합격입니다.")
    else:
        print(f"수험번호 : {tno} 불합격입니다.")