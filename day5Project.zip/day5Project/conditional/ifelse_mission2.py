# conditional\\ifelse_mission2.py
# conditional.ifelse.mission2


def practice2():
    value = int(input("나눌값 :"))
    div_num = int(input("나누기할 수 :"))


    if(div_num != 0):
        print("몫 : {}".format(value // div_num))
        print("나머지 : {}".format(value % div_num))
    else:
        print("나누길 할 수가 0으로 나눌 수 없습니다")

    print("프로그램이 종료되었습니다")
