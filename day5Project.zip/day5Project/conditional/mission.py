# mission.py
# 다중 if 문 실습문제

def practice4():
    name = input("학생이름 : ")
    score = int(input("점수 : "))
    grade = ["A", "B", "C", "D", "F"]
    if(score >= 90):
        print(f"{name}의 점수는 {score}점이고, 등급은 {grade[0]}입니다.")
    elif(score >= 80):
        print(f"{name}의 점수는 {score}점이고, 등급은 {grade[1]}입니다.")
    elif(score >= 70):
        print(f"{name}의 점수는 {score}점이고, 등급은 {grade[2]}입니다.")
    elif(score >= 60):
        print(f"{name}의 점수는 {score}점이고, 등급은 {grade[3]}입니다.")
    elif(score < 60 ):
        print(f"{name}의 점수는 {score}점이고, 등급은 {grade[4]}입니다.")
    print("감사합니다. ")

# 해석방법 2:   grade = "F"
               # if(score >= 90):
               # grade = "A"
               # if(score >= 80):
               # grade = "B"
               # if(score >= 70):
               # grade = "C"
               # if(score >= 60):
               # grade = "D"

# 중첩 if 문
def practice5():
    num1 = int(input("첫번째 수 : "))
    num2 = int(input("두번째 수 : "))

    if(num1 > 0 and num2 > 0):
        if(num1 <= 100 and num2 <= 100):
            print("{} + {} = {}".format(num1, num2, num1 + num2))
            print("{} - {} = {}".format(num1, num2, num1 + num2))
            print("{} * {} = {}".format(num1, num2, num1 + num2))
            print("{} // {} = {}".format(num1, num2, num1 + num2))
            print("{} % {} = {}".format(num1, num2, num1 + num2))
        else:
            print("1~100 사이의 값만 입력하세요.")
    else:
        print("양수만 입력해야 됩니다.")
    print("프로그램이 종료되었습니다.")

