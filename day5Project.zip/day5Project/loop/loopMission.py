# loop/loopMission.py
# loop.loopMission


"""
    키보드로 문자열을 입력받아서, 요구대로 처리하고 출력되게 하시오.
    실행 :
            문자열 입력 : apple (value : str)
    처리내용 :
            for 문 사용 : 각 글자의 유니코드 출력이 반복되게 함.
    출력 :
            a is unicode 97
            p is unicode 97
            p is unicode 97
            l is unicode 97
            e is unicode 97



"""




def practice1():
    value = input("12345:")
    for vt in value:
        print(f"{vt} 문자의 유니코드는 {ord(vt)}")

def practice2():
    dan = int(input("단수 입력:"))
    for su in range(1, 10):
        print(f"{dan} * {su} = {dan * su}")


