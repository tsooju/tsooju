# This is a start Python script.

# import conditional.mission as ms

# if __name__ == '__main__':
    # ifsam.iftest()
    # ifsam.iftest2()
    # ifsam.testEven2()
    # ifsam.test_ifelse()
    # ifsam.test_in()
    # ifsam.checkPayment()
    # ifsam.checkPayment2()
    # ifsam.practice2()
    # ifsam.practice3()
    # ms.practice4()
    # ms.shortCondition()
    # ms.shortCondition2()
    # ms.practice5()

# module 은 자바에서 package랑 같은 개념.

import loop.loopMission as lp2
if __name__ == '__main__':
    # lp.for_list()
    # lp.for_tuple()
    # lp.for_set()
    # lp.for_str()
    # lp.for_sum()
    # lp.test_iterable()
    # lp.test_range()
    # lp.for_indexing()
    # lp2.practice1()
    lp2.practice2()