# loop\\forMission.py
# loop.forMission

def product_process():
    product_list1 = []

    for i in range(3):
        print(i, "번째 기로할 제품정보를 입력하세요.")
        pno = int(input("제품번호 : "))
        pname = input("제품명 : ")
        price = int(input("가격 : "))
        tex = int(input("부가세 : "))
        amount = int(input("구매수량 : "))

        product_list1.append([pno, pname, price, tex, amount])

        total_price = (price + (price * tex)) * amount
        product_list1[i].append(total_price)

    for i in range(len(product_list1)):
        print(i,"번째 기록할 제품정보.","--------------")
        pno, pname, price, tex, amount, total_price = product_list1[i]
        print("제품번호 : ", pno)
        print("제품명 : ", pname)
        print("가격 : ", price)
        print("부가세 : ", tex)
        print("구매수량 : ", amount)
        print("구매가격 : ", int(total_price))












# 함수 실행함=========================================================
if __name__ == '__main__':
    product_process()