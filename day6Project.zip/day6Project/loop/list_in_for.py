# loop\\list_in_for.py
# loop.list_in_for


# 리스트 내포 (내부에 포함)
# 리스트 내에 값 추가를 위한 for 문을 포함하는 구문
# [아이템 for 아이템 in 시퀀스객체]   윈쪽 아이템에 추가 된다는 것이다.
# 주의 : 아이템은 이름이 반드시 같아야 함.
# 시퀀스객체(iterable) : 순차적으로 값을 저장하는 객체(str, list, tuple, set)



# list에 값을 기록하는 방법 1:
def list_append():
    sample_list = list()  # sample_list = []
    for n in range(1, 6):
        sample_list.append(n)
    print(sample_list)


# 리스트 내포로 바꾼다면 :
def list_append2():
    sample_list = [n for n in range(1, 6)]
    print(sample_list)

# 리스트 내포시에 if문과 같이 포함할 수 있음
def list_append3():
    sample_list = []
    for k in range(1, 11):
        if(k % 2 == 0):
            sample_list.append(k)
    print(sample_list)

# 리스트 내포로 바꾼다면 :
def list_append4():
    sample_list = [k for k in range(1, 11) if(k % 2 == 0)]
    print(sample_list)

# for 문 안에 for 문이 사용되는 경우 (다중 for 문)
def list_append5():
    sample_list = []
    for k in range(1, 6):
        for m in range(1, 6):
            sample_list.append(k +m)
    print(sample_list)

# 리스트 내포로 바꾼다면
def list_append6():
    sample_list = [k + m for k in range(1, 6) for m in range(1, 6)]
    print(sample_list)


#  구구단 2단부터 9단까지 곱하기한 결과값을 리스트에 저장 처리함.
# 리스트 내포로 저장되게 하고 출력 확인함

def gugudan_result():
    sample_list = [k * m for k in range(2, 10) for m in range(1, 10)]
    print(sample_list)


# 바로 파일 안에서는 실행시 import 할 필요없다. 대신 if는 함수 아래쪽에 작성해야 한다.


if __name__ == '__main__':
    # list_append()
    # list_append2()
    # list_append3()
    # list_append4()
    # list_append5()
    # list_append6()
    gugudan_result()
