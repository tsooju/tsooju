# loop\\loopMission.py
# loop.loopMission


"""
리스트 안의 튜플 아이템의 값들에 대해
들 중의 큰값과 작은 값을 분류해서 출력처리

"""

# 방법 1 : 조건식 직접 작성
def practice1():
    nlist = [(12, 45), (90, 32), (56, 19)]
    # for 문 안의 if else 문 사용
    for (first, second) in nlist:
        if first > second:
            max = first # 큰 값 저장
            min = second # 작은 값 저장

        else:
            max = second  # 큰 값 저장
            min = first # 작은 값 저장

        print(f"큰값 : {max}, 작은 값 : {min}")

# 방법 2
def practice2():
    nlist = [(12, 45), (90, 32), (56, 19)]
    # for 문 안의 if else 문 사용
    for (first, second) in nlist:
        tmax = max(first, second)  # 큰 값 저장
        tmin = min(first, second)  # 작은 값 저장


        print(f"큰값 : {max}, 작은 값 : {min}")

# 활용 실습 : 조건식 직접 작성
# 리스트 안의 군집아이템 가진 값들 중 각각 가장 큰 값을 골라 내서
# 별도의 리스트에 저장 처리하고 출력 확인


def practice3():
    mlist = [[43, 1, 20], (22, 41, 10, 73), {12, 32, 45, 3, 9}]
    max_list = []
    for item in mlist:
        print(item, type(item))
        max_value = 0
        for n in item:
            if max_value < n:
                max_value = n
        max_list.append(max_value)

    print(max_list)


# 내장함수 max(iterable) 사용 가능
def practice4():
    mlist = [[43, 1, 20], (22, 41, 10, 73), {12, 32, 45, 3, 9}]
    max_list = []
    for item in mlist:
        print(item, type(item))
        max_list.append(max(item))
    print(max_list)


# def practice5():
#     while(True):
#         print()

print("break 사용")
num = 10
while(num > 0):
    if(num == 6):
        print("--end--")
        break
    print(num)
    num -= 1

# num1 = 10
# while(num1 > 0):
#     print(num, end = ",")
#     if(num1 == 6):
#         continue
#     num1 -= 1

print("list 안에 for 문")
# [식 for 변수 in 반복 가능한 객체 if 조건]로 정의한다.
# 방법 1
l = []
for i in range(5):
    l.append(i)
print(l)

# 방법 2
print([i for i in range(5)])


n = []
for d in range(3):
    for f in range(3):
        n.append(d+f)
print(n)


def practice_while():
    sungjuk_list = [[12, "홍길동", 98], [15, "김유신", 87], [23, "황지니", 45]]
    # for student in sungjul_list:
    #     if(student[2] >= 60)
    #         print("{}번 {} 학생은 합격입니다.".(student[0], student[1]))
    #     else:
    #         print("{}번 {} 학생은 불합격입니다.".(student[0], student[1]))


    idx = 0
    while idx < len(sungjuk_list):
        student = sungjuk_list[idx]
        idx += 1
        if (student[2] >= 60):
            print("{}번 {} 학생은 합격입니다.".format(student[0], student[1]))
        else:
            print("{}번 {} 학생은 불합격입니다.".format(student[0], student[1]))

# 2. for 문 안에 continue를 사용해서 합격정보만 출력되게 처리하시오

def practice_continue1():
    sungjuk_list = [[12, "홍길동", 98], [15, "김유신", 87], [23, "황지니", 45]]
    for student in sungjuk_list:
        if student[2] < 60:
            continue
        print("{}번 {} 학생은 합격입니다.".format(student[0], student[1]))


def practice_continue2():
    sungjuk_list = [[12, "홍길동", 98], [15, "김유신", 87], [23, "황지니", 45]]
    idx = 0
    while idx < len(sungjuk_list):
        student = sungjuk_list[idx]
        idx += 1
        if (student[2] < 60):
            continue
        print("{}번 {} 학생은 합격입니다.".format(student[0], student[1]))



def practice_short_if():
    sungjuk_list = [[12, "홍길동", 98], [15, "김유신", 87], [23, "황지니", 45]]
    for student in sungjul_list:
        print(f"{student[0]}번 {student[1]} 학생은 합격입니다." if(student[2] >= 60) else f"{student[0]}번 {student[1]} 학생은 불합격입니다.")

# ---------------------------------------------------------------------------------------------------------------------#

import random

# random : 임의의 숫자(ramdom값)를 발생기키고자 할 때 사용 한다.
# random module의 제공하는 함수를 사용할 수 있음.

def test_random():
    print("임의의 값 : ", random.random())
    # 0.0 이상 <= 랜덤값 < 1.0 범위의 임의의 실수형 숫자가 발생함

    print("random 확인 : ", random.randrange(1, 11))
    # start <= random값 < end 범위의 임의의 정수형 숫자가 발생함.

def display_lotto():
    numbers = set()  # сэт ашиглаж байж давхардсан тоо орохгүй байлгах

    while len(numbers) < 6:  #  6 хүртлэх тоог бичнэ гэсэн үг
        numbers.add(random.randrange(1, 46))

    lotto_numbers = list(numbers) # set을 list 로 바꿈
    lotto_numbers.sort(reverse=False)  # 오름차순 정력 처리
    print("이번 주 로또 예상 번호 : ", lotto_numbers)





