# loopSample.py
# loop.loopSample

# for 문은 사용하는 형식이 군집자료입니다.
# 아니면 데이터를 인덱스처리 해서 사용하는 방식 있다.
# 아니면 range() 함수를 이용한다.


# 반복이 반복될 때 for 문 안에 for 문 사용할 수 있음.
# 안쪽 for 문이 여러 번 반복된다.
# 구구단 2단부터 9다까지 출력 처리

def doubleFor():
    dan = int(input("단수 입력 : "))
    for dan in range(2, 10):
        print(dan)#2단부터 9단까지 8번 반복 처리
        for i in range(1, 10):  # 하나의 단에 대한 구문 9번 출력
            print(f"{dan} * {i} = {dan * i}")
        print("-------------")


def doubleFor1():
    t = [[1,2], [3,4], [5,6]]
    for i,j in t:
        print(i+j)


# list(tuple, set) 안에 list(tuple, set)가 저장된 경우
# 첫번째 추출은 안의 리스트 전체 추출임
# 안의 리스트가 가진 값들을 하나씩 처리해야 하는 경우
# 이중 for 문 사용할 수 있음.
# 안의 리스트들이 가진 값의 갓수가 동일한 경우에는 단순 for 문으로 해결

def list_in_list(): # 안의 리스트가 동일한 경우
    fruits_list = [["apple", 10, 500], ["banana", 3, 2500], ["orange", 15, 350]]
    for fname, famount, fprice in fruits_list:
        print(f"{fname} 의 단가는 {fprice}원이고, 구매수량은 {famount}개, 구매가격은 {fprice * famount} 원입니다.")


# list 안의 list의 값 갯수나 기록현태가 제각각인 경우
# 안의 리스트의 값들을 각각 처리해야 하는 경우는 이중 for문 사용

def list_in_list2():
    nlist = [["a", "bb", "cde"], [10, 20], [1.2, 3.5, 33, 78.90]]
    for item in nlist:
        print(item)  # 안의 리스트
        for data in item:
            print(data)
        print("--------------")

# 위의 list를 인덱스로 처리할 수도 있음.
def list_in_list3():
    nlist = [["a", "bb", "cde"], [10, 20], [1.2, 3.5, 33, 78.90]]
    for index in range(len(nlist)):  # range(3) : 0 ~ 2
        print(nlist[index])  # 안의 리스트
        for j in range(len(nlist[index])):  # 안의 리스트의 값의 갯수
            print(f"nlist[{index}][{j}] : {nlist[index][j]}")
        print("--------------")


def cnt():
    s = "hello"
    cnt = 0
    for i in s:
        if(i == "e"):
            print("i is e")
        cnt += 1
    print(cnt)

#  필요한 경우 반복문 안에 조건문을 사용할 수도 있음.
# 예 : 문자열에서 특정 문자의 포함갯수를 조회하고자 한다면
# 문자열과 찾을 문자를 입력받고, 문자열 안의 찾는 문자의 갯수 조회
def loop_in_conditional():
    st = input("문자열 입력 : ")
    ch = input("찾는 문자 입력 : ")
    cnt = 0  # 갯수를 찾을 거라서 0부터 시작

    for c in st:
        if c == ch:  # 꺼낸 문자가 찾는 문자이면
            cnt += 1 # 카운트 1 증가함
    print(f"{st} 안에 포함된 {ch}의 갯수는 {cnt} 개임")



# 문자열 안의 찾는 문자를 제외한 글자 갯수 조회
def loop_in_conditional2():
    st = input("문자열 입력 : ")
    ch = input("찾는 문자 입력 : ")
    cnt = 0  # 갯수를 찾을 거라서 0부터 시작

    for c in st:
        if c != ch:  # 꺼낸 문자가 찾는 문자이면
            cnt += 1 # 카운트 1 증가함
    print(f"{st} 안에 포함된 {ch}를 제외한 문자의 갯수는 {cnt} 개임")

"""
제어(처리) 문 : 조건문, 반복문, 분기문
분기문 : 실행의 흐름을 바꾸는 구문
  => 제한 1 : if 문과 함께 사용함 
    for | while 반복저건 : 안에서 사용할 수 있음 
        사용 패턱 : if 조건식 : 
                         continue  # 반복문 중간 생략 (таслал)하고 반복으로 넘어감
                         # 아래(밑)의 내용을 실행하지 않고 for | while 로 넘어감. 
                   if 조건식 : 
                         break  # 반복문을 강제로 종료시킴 (төгсгөл)
                   반복 처리 구문들
  => 제한 2 : 반복문 내에서만 사용할 수 있음
"""


# 1부터 100까지 정수 중에서 짝수들의 함계만 구하는 경우
# range() 이용, continue 이용 2까지를 사용 가능

# continue 이용 : 짝수 계산
def sum_1to100():
    sum = 0
    for n in range(1, 101):  # (1 ~ 100까지 1단계씩 가는 정수)
        if n % 2 == 1:
            continue
        print(n, "+", end="")
        sum += n
    print(f"\n1부터 100까지 짝수들의 합계 : {sum}")

# continue 이용 : 홀수 계산
def sum_1to100_2():
    sum = 0
    for n in range(1, 101):  # (1 ~ 100까지 1단계씩 가는 정수)
        if n % 2 == 0:
            continue
        print(n, "+", end="")
        sum += n
    print(f"\n1부터 100까지 짝수들의 합계 : {sum}")

# 리스트 안의 튜플이 가진 값에 대한 변수 지정시에는
# (변수명, 변수명, ...) 소괄호 묶어서 변수 지정함

def list_in_tuple():
    nlist = [(12, 45), (90, 32), (56, 19)]

    # for item in list:
    #     print(item)

    # for a, b in list:
    #     print(a, b)

    for(a, b) in nlist:
        print(a, b)




# while문 --------------------------------------------------
"""
while (반복을 위한 조건식): => 조건의 결과가 참일 동안 계속 반복됨
    반복 실행 구문
    반복 실행 구문
조건의 결과가 거짓이면 반복은 종료되고 다음 구문으로 넘어감. 
주의사항 : 반복의 조건식 결과가 계속 True 이면 무한루프에 빠짐
"""

def test_while():
    num = 5
    while num > 0:
        print(num)
        num -= 1


# 반복에 대한 조건식에 True를 사용할 수도 있음
# 주의 : 무한루프가 되지 않게 if 조건문과 break 문을 반복문 안에 작성
# 이런 것은 두 while잉 문자와 같다.
# 기존에 카운트가 필요하면 for문을 사용하고 필요 없으면 while문을 주로 사용한다.

def test_while2():
    num = 5
    while True:
        print(num)
        num -= 1
        if num == 0:
            break


# 반복 횟수가 정해지지 않은 경우 while 문을 주로 사용함.
# 문자 하나를 입력받아서, 그 문자의 유니코드 출력하는 처리를 반복함.
# 단, 0 문자가 입력되면 반복이 종료됨.


def print_unicode():
    name = input("문자하나 입력[0입력시 종료됨] : ")

    while name != "0":
        print(f"{name} is unicode : {ord(name)}")
        name = input("문자하나 입력[0입력시 종료됨] : ")

def print_unicode2():
    while True:

        n = input("문자하나 입력[0입력시 종료됨] : ")
        if n == "0":
            break

        print(f"{n} is unicode: {ord(n)}")


#  ------------------------------------------------------------------------- #
# 파이선에서 여러 줄의 문자열을 표현할  때 3쌍의 따옴표를 이용할 수 있다.

def display_menu():
    prompt = """
    *** 원하는 메뉴 번호를 선택하세요 ***
    1. 추가
    2. 삭제
    3. 출력
    4. 끝내기
    
    """
    # print(prompt)
    while True:
        print(prompt)
        no = int(input("번호 입력 : "))

        if no == 4:
            break
    print("===== end =====")
















