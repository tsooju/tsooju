# loop\\whileMission.py
# loop.whileMission

# while 문 실습문제

def sungjuk_process():
    sungjuk_list = [[12, "홍길동", 98], [15, "김유신", 87], [23, "황지니", 45]]
    prompt = """
    *** 원하는 메뉴 번호를 선택하세요 ***
    1. 추가
    2. 삭제
    3. 출력
    4. 끝내기

    """
    # print(prompt)
    while True:
        print(prompt)
        no = int(input("번호 입력 : "))
        if no == 1:
            son = int(input("번호 : "))
            sname = input("이름 : ")
            score = int(input("점수 : "))
            sungjuk_list.append([son, sname, score])
            print("새로운 학생정보가 추가되었습니다.")
            print(sungjuk_list)
        elif no == 2:
            remove_item = input(f"현재 저장된 아이템의 갯수는 {sungjuk_list.remove(len())}입니다. 제거할 "
                            f"번호를 입력하세요[0, 1, 2, 3] : ")

            print("잘못 입력 했습니다.")
        # 제거할 순번을 입력받아서 리스트에 주가하는 작업
        elif no == 3:
            for idx in range(len(sungjuk_list)):
                print(f"{idx} : {sungjuk_list[idx]}")
        elif no == 4:
            break
    print("===== end =====")












if __name__ == '__main__':
    sungjuk_process()

