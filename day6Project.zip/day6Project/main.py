# This is a project start Python script.


# import loop.loopSample as ls
# import loop.loopMission as lm

# if __name__ == '__main__':
    # ls.doubleFor()
    # ls.doubleFor1()
    # ls.list_in_list()
    # ls.list_in_list2()
    # ls.list_in_list3()
    # ls.cnt()
    # ls.loop_in_conditional()
    # ls.loop_in_conditional2()
    # ls.sum_1to100()
    # ls.sum_1to100_2()
    # ls.list_in_tuple()
    # lm.practice1()
    # lm.practice2()
    # lm.practice3()
    # lm.practice4()
    # ls.test_while()
    # ls.test_while2()
    # ls.print_unicode()
    # ls.print_unicode2()
    # ls.display_menu()
    # lm.practice_continue1()
    # lm.practice_continue2()
    # lm.test_random()
    # lm.display_lotto()


