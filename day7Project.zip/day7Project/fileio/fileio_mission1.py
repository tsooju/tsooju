# fileio_mission1.py
# 파일입출려그 반복문, 리스트, 딕셔너리 사용 실습문제


import pickle
import os


def emp_process():
    emp_dict = dict()

    prompt = """ 
    *** 직원 정보 관리 프로그램 시작 ***
    1. 새 직원정보 추가
    2. 직원정보 삭제
    3. 전체 출력
    4.파일에 저장
    5. 파일로부터 직원정보 읽어오기
    6. 프로그램 끝내기
    """

    while True:
        print(prompt)
        no = int(input("번호 입력 : "))
        emp_dict = dict()
        if no == 1:
            empid = input("사번입력 : ")
            empname = input("이름입력 : ")
            empno = input("주민번호입력 : ")
            email = input("이메일입력 : ")
            phone = input("전화번호 : ")
            salary = int(input("급여 : "))
            job = input("직급 : ")
            dept = input("부서 : ")
            emp_dict.update({empid : [empname, empno, email, phone, salary, job, dept]})
            print("직원정보가 추가 되었습니다.")


        elif no == 2:
            remove_empid = input("삭제 할 사번 임력 : ")
            if remove_empid == len(emp_dict):
                emp_dict.pop(remove_empid)
            print(f"{len(emp_dict)}번 사번의 직원 정보가 삭제되었습니다.")


        elif no == 3:
            # for key, value in emp_dict.items():
            #     print(f"{} : {}"(key, value))
            print(emp_dict)


        elif no == 4:
            # fname = input("저장할 파일명 : ")
            # f = open(fname, "wb")
            # pickle.dump(emp_dict, f)
            # f.close()
            # print(f"{fname} 파일에 성공적으로 저장되었습니다.")
            #


            f = open("employees.dat", "wb", encoding="utf-8")
            file = str(emp_dict)

            f.close()
            print("employees.dat 파일에 성공적으로 저장되었습니다.")

        elif no == 5:
            f = open("employees.dat", "rb", encoding="utf-8")
            print("파일의 내용을 읽어서 딕셔너리(emp_dict)에 저장하고 출력되게 함")


        elif no == 6:
            print("프로그램 종료되었습니다.")
            break



