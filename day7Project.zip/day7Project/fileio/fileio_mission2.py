# fileio_mission2.py



def emp_process2():
    emp_dict = dict()

    prompt_menu = """ 
    *** 파이썬 메모장이 샐댛되었습니다. ***
    1. 새로 만들기
    2. 저장하기
    3. 불러오기
    4. 끝내기
    
    """

    while True:
        print(prompt_menu)
        no = input("번호입력 : ")
        if no == "1":
            nfile = input("내용을 입력하세요 : ")
            contents = ""
            while True:
                in_str = input()

                if in_str == "end":
                    print("반복이 종료됩니다.")
                    break
        elif no == "2":
            saving_file = input("저장할 파일명을 입력하새요 : ")
            f = open(saving_file, "w", encoding="utf-8")
            f.write(contents)
            f.close()
            print("성공적으로 저장되었습니다.")
        elif no == "3":
            saving_file = input("읽을 파일명을 입력하새요 : ")
            f = open(saving_file, "w", encoding="utf-8")
            contents = f.read()
            f.close()
            print(contents, end="")
        elif no == "4":
            break