# This is a start Python script.

# import fileio.fileio_sample as fio
import fileio.fileio_mission2 as fio3
import os

if __name__ == '__main__':
    # fio.test_fwrite()
    # fio.test_fwrite2()
    # fio.test_fwrite3()
    # print(os.getcwd())  # cwd(current working directory) : 현재 작업 디렉터리
    # fio.test_osmodule()
    # fio.test_fwritelines()
    # fio.test_fread()
    # fio.test_fread2()
    # fio.test_binary_fio()
    # fio.test_binary_fio2()
    # fio.change_stdinout()
    # fio.test_os()
    # fio2.emp_process()
    fio3.emp_process2()
