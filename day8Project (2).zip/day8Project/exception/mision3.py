# mission3.py
# 사용자 정의 예외 발생 실습문제

def calc_score(a, b):


    if ((a >= 1 and a <= 100) and (b >= 1 and b <= 100)):
        return a + b, a - b, a * b, a // b, a % b
        # raise Exception("1이상 100 이하의 숫자를 입력하새요 : ")
    else:
        # return a + b, a-b, a * b, a // b, a % b
        raise Exception("1이상 100 이하의 숫자를 입력하새요 : ")

def test_mission():
    try:
        num1 = int(input("숫자 하나 입력 : "))
        num2 = int(input('숫자 하나더 입력 : '))

        result = calc_score(num1, num2)
        print(result)

    except Exception as msg:
        print(msg)


    finally:
        print("프로그램 종료")


if __name__ == '__main__':
    test_mission()