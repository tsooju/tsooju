# mission1.py
# 예외처리 실습문지 1


try:
    num = int(input("단수를 입력하세요 : "))
except ValueError as msg:
    print("정수만 입력해야 됩니다.", msg)
except Exception as msg:
    print("에러 발생 : ", msg)
else:
    if num < 2:
        num = 2
    elif num > 9:
        num = 9

    for su in range(1, 10):
        print(f"{num} * {su} = {su * num}")
