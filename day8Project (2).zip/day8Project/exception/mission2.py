# mission2.py
# 예외처리 실습문제 2

# try except finally 사용하시오
def calculator1():

    try:
        num1 = input("가로숫자 입력 : ")
        num2 = input("새로숫자 입력 : ")
        num1 = int(num1)
        num2 = int(num2)
        print(f"사각형 면젹 : {num1} * {num2} = {num1 * num2}")
        print(f"사각형의 둘레 : {2 * (num1 + num2)}")

    except ArithmeticError as msg:
        print("숫자만 입력해야 됩니다.", msg)
    except Exception as msg:
        print("숫자만 입력하세요 : ", msg)

    finally:
        print("프로그램 종료합니다.")


# try , except, else
def calculator2():
    try:
        num1 = input("가로숫자 입력 : ")
        num2 = input("새로숫자 입력 : ")
    except:
        print("숫자만 입력하세요 : ")
    else:
        num1 = int(num1)
        num2 = int(num2)
        print(f"사각형 면젹 : {num1} * {num2} = {num1 * num2}")
        print(f"사각형의 둘레 : {2 * (num1 + num2)}")
    finally:
        print("프로그램 종료합니다.")





if __name__ == '__main__':
    # calculator()
    calculator2()