# func_missio1.py
# 함수 만들고 사용하기 실습문제 1





def tsum(a, b):

    return a + b

def tsub(a, b):

    return a - b

def tmul(a, b):

    return a * b

def tdiv(a, b):

    return a // b
def ttub(a, b):
    return a % b


def simple_culcolator():
    try:
        num1 = int(input("숫자 입력 : "))
        num2 = int(input("숫자하나 더 입력 : "))
    except Exception as msg:
        print("에러 발생", msg)
    else:
        result1 = tsum(num1, num2)
        result2 = tsub(num1, num2)
        result3 = tmul(num1, num2)
        result4 = tdiv(num1, num2)
        result5 = ttub(num1, num2)

        print(result1)
        print(result2)
        print(result3)
        print(result4)
        print(result5)
    finally:
        print("end")



if __name__=="__main__":
    simple_culcolator()
