# func_mission2.py
# 함수 만들고 사용하기 실습문제 2

def find_chr(a, b):
    count = 0
    for a in b:
        if a == b:
            count += 1
    return count

def func_string():
    try:
        str1 = input("문자열 입력 : ")
        b = input("찾을 문자 입력 : ")
        print(find_chr(str1, b))
        # result = (str1, str2)
        # for idx in str1:
        #     print(result)
    except Exception as msg:
        print("문자만 입력 가능", msg)

    finally:
        print("the end")









if __name__ == "__main__":
    func_string()