# func_mission3.py
# 함수 만들고 사용하기 실습문제 3

def person_security(pno):
    return pno

def enroll():
    try:
        name = input("이름 : ")
        person_no = input("주민등록번호 : ")

        person_no = person_no[0:6] + "******"
        pno = person_no
        print(pno)

    except Exception as msg:
        print("에러 발생 : ", msg)


    finally:
        print("프로그램 종료")
















if __name__ == "__main__":
    enroll()