# except_sample.py
# 파이선에서의 예외처리 (exception handling)
"""
예외 : 소스 코드로 해결할 수 있는 에러
에러의 종류 :
        시스템 에러 : 소스 코드로 해결 못하는 에러임
        예 : 메모리 부족, 하드디스크(저장장치) 용량 부족, 베터리 양 부족

        구문(문법) 에러 : 잘 못 작성된 에러임. 개발툴 ide에서 자동 검사함. 구무능 수정해서 해결함.

        런타임 에러 : 샐행시 발생항는 (사용자의 의해 들어오는) 에러
                    에러 발생이 되면 코드를 수정헤서 해결함 => 예외 처리함.

에러처리 방법 :
        if 조건문으로 에러 상황을 예측해서 미리 막아주는 작업
         하지만 :
        => 예외상황을 처리하는 별도의 구문이 있음.
        => 예외처리 구문 사용을 권장함

"""

def test_error():
    # error 발생 예시 :
    # print("exception"   # SyntaxError: invalid syntax (구문 오류)

    # a = 10
    # b = 0
    # c = a / b    # ZeroDivisionError: division by zero, 샐행시 확인되는 에러 즉 (런타임 에러)

    # 4 + new * 3  # (구문 에러), NameError: name 'new' is not defined (예약어를 그대로 사용할 수 없다.)

    lst = [1, 2]
    # print(lst[2])   # IndexError: list index out of range  (런타임 에러)


    dict = {"a": 100, "b": 200}
    # print(dict["c"])   # KeyError: 'c'   (런타임 에러)

# 런타임 에러 중에 사용자가 입력값을 잘못 입력하는 경우
def test_input_error():
    # num = int(input("정수를 입력하세요 : "))  # ValueError: 실행중에 발생 : 런티임 에러
    # if 문으로 처리할 수 없는 에러 상황 발생하였음  => 예외처리 구문으로 해결


    # 해결방법 1 : 입력시 조건문을 적용
    num = input("정수를 입력하세요 : ")
    if num.isdecimal():  # 정수 십진수냐 맞으면
        num = int(num)
        print(num, type(num))
    else:
        print("정수만 입력해야 됩니다. 다시 입력하세요.")





















if __name__ == '__main__':
    # test_error()
    test_input_error()