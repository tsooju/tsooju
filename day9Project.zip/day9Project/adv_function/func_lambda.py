# func_lambda.py
# 파이선에서 람다함수 만들기

# 람다 함수 개념 :
"""
리스트 내포, 간단 조건문 처럼 여러 줄로 된 코드를 간결하게 표현할 수 있는
새로운 함수 정의 방법
def 로 정의하는 함수를 간단하게 lambda 로 작성함.
대신 : 한줄로 표현 가능한 처리 내용일 떄 주로 이용가능.
일회성 코드일 때 이용할 수 있음.

함수 이름 없음. 참조변수가 함수이름을 대신할 수 있음.

작성과 사용법 :
참조변수 : lambda 매개변수, 매개변수: 처리구문
사용 1 : 참조변수(전달값, 전달값)
 사용 2 : (lambda 매개변수, 매개변수 : 처리구문)(전달값, 전달값)
"""

# 일반함수 만들기
def add(x,y):
    return x + y


# lambda 함수 만들기
add2 = lambda x, y: x + y

if __name__ == '__main__':
    # 일반함수실행
    result = add(10, 20)
    print("더하기 : ", result)


    # lambda 실행(사용)
    result = add2(10, 20)
    print("람다확인 : ", result)


    # 주로 이용하는 방식은 : 람다 함수 작성과 실행을 함께 처리
    print("람다 한줄 더하기 결과 : ", (lambda x, y: x + y)(10, 20))  # 일회용으로 줄어듬

    # 람다함수의 매개변수에도 기본, 키워드, 가변 매개변수 적용할 수 있음

    print("(기본)람다 한줄 더하기 결과 : ", (lambda x, y=20: x + y)(10))
    print("(키워드)람다 한줄 더하기 결과 : ", (lambda x, y: x + y)(y = 10,x = 20))
    print("(가변)람다 한줄 더하기 결과 : ", (lambda x, *y: x * y)(3, 1, 2, 3))  # tuple의 곱은 반복이다.

    # 람다 함수 안에 간단 조건문 사용할 수 있음
    print((lambda x, y: x if x % 2 == 0 else y )(3, 5))


    # map()
    print(list(map(lambda x: x * x, [1, 2, 3, 4, 5])))
    # filter()
    print(list(filter(lambda x: x > 2, [23, 1, 4, 56])))


















