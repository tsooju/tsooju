# func_mission.py
# 재귀함수, 람다함수, 내장함수 실습문제

def fectorial(n):
    print(n, "*", end=" ")
    if n == 0:
        return 1
    else:
        return n * fectorial(n - 1)

def test1():
    num = int(input("정수 입력 : "))
    return fectorial(num)
def test2():
    num = int(input("정수 입력 : "))
    print((lambda n: n == 0 and 1 or n * fectorial(n-1))(num))
    # return list(lambda num2 = int(input("정수 입력 : ")): fectorial(num2))

def test3():
    num = int(input("정수 입력 : "))
    result = 1   # 곱 하기 때문에 1부터 시작하는 것이다.
    for i in range(num, 0, -1):
        result *= n
        print(result)
def test4():
    num = int(input("정수 입력 : "))

    print([num * su for num in range(2, 10) for su in range(1, 10)])


def test5():
    print([(lambda d,s: f"{d} * {s} = {d * s}")(num, su) for num in range(2, 10) for su in range(1, 10)])

def test6():
    pass            # print((lambda a: if a > 10 esle)(14))

def test7():
    # print(test_func2(5))
    print(list(map(lambda a: a ** 2, range(5))))


def test_func2(a):
    ls = []
    for i in range(a):
        ls.append(i ** 2)
    return ls

# 함수 실행 ----------------------------------------
def func_mission():
    prompt = """
    *** 함수 활용 테스트 ***
    1. 재귀함수 : 입력받은 정수의 펙투리얼 구하기 
    2. 람다함수 : 입력받은 정수의 펙투리얼 구하기 
    3. 반복문 사용 : 입력받은 정수의 펙투리얼 구하기
    4. 리스트 내포 : 구구단 2단 ~ 9단 까지 곱하기 결과 저장 출력
    5. 람다함수와 리스트 내포 : 구구단 2단 ~ 9단 까지 곱하기 결과 저장 출력
    6. 람다함수로 바꾸기 실습
    7. map() 함수와 람다함수 사용으로 바꾸기 실습
    0. 끝내기   
    """

    while True:
        try:
            print(prompt)
            no = int(input("번호 입력 : "))
        except:
            print("숫자만 입력하세요.")
        else:
            if no == 1:
                test1()
            elif no == 2:
                test2()
            elif no == 3:
                test3()
            elif no == 4:
                test4()
            elif no == 5:
                test5()
            elif no == 6:
                test6()
            elif no == 7:
                test7()
            elif no == 0:
                print("실행 작업 종료")
                break
            else:
                print("잘못 입력하셧습니다. 다시 입력하세요")




# 실습문제 실행 테스트 ----------------------------------------
if __name__ == '__main__':
    func_mission()

