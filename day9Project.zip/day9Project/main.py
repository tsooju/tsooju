# This is a start Python script.



def recursive(num):
    print(num)
    num += 1
    recursive()


if __name__ == '__main__':
    recursive(num)


