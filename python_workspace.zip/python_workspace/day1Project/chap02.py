import keyword
print(keyword.kwlist)


num1 = 10
num2 = 20
print(num1 <= num2)



