# chap02_example1.py
# 복습문제 1

# 23번 홍길동 과목총점은 270점이고 평균은 90.0점


student_name = input('학생이름 : ')
student_no = int(input('학생번호 : '))
kor = int(input('국어점수 입력 : '))
eng = int(input('영어점수 입력 : '))
math = int(input('수학점수 입력 : '))

tot = kor + eng + math
avg = tot / 3

print('{}번 {}의 과목총점은 {}점이고 평균은 {}점'.format(student_no, \
                                           student_name, tot, avg))



