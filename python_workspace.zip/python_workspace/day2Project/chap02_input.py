# chap02_input.py
# 2022.05.27
# developer : ganaa


# 파이썬에서 실행시 키보드로 값 입력받기
# input() 란 함수 사용함.
# 먼저 변수이름 작성하고 = inpur('입력을 위한 메세지 문장')


# 입력을 위한 메세지 없이 실행 테스트

# ｎｕｍ　＝　ｉｎｐｕｔ（숫자를　　입력해주세요）
# num = input('숫자를 입력하세요 : ')
# print('num :' , num )
# print('num에 저장된 값의 종류 : ', type(num))

# 파이썬의 input() 함수로 입력되는 값은 모두 문자형(str) 이다. str - 문자란 뜻이며 계산할 수 없는 글자라고 말한다.

# print('더하기 확인 : ', num + 100)

# 숫자형으로 바구고자 한다면 , 정수는 int('정수문자'), 실수는 flout('실수문자') 함수 사용함

# int_num = int(num)
# print('int_num :', int_num, type(int_num))
# print('더하기 확인 :', int_num + 100)



# 실습문제
'''
2개의 정수 숫자를 각각 업력받아, 각 변수에 할당하고 
두 수의 합, 차, 곱, 몫, 나머지를 연산하여 출력 확인하는 코드를 완성하시오
첫번째 정수 : 25
두번째 정수 : 17
출력 예 : 
25 + 17 = 42
25- 17 = 8
25 * 17 = 425
//
%
** 2 
** 2 

'''

value = 25 + 17
print('value: ', value)
value = 25 - 17
print('value: ', value)
value *= 17
print('value: ', value)
value // 17
print('value: ', value)














