first = int(input('첫번째 정수 : '))
second = int(input('두번째 정수 : '))

print(first, '+', second, '=', (first + second))
print(first, '-', second, '=', (first + second))
print(first, '*', second, '=', (first + second))
print(first, '//', second, '=', (first + second))
print(first, '%', second, '=', (first + second))
print(first, '**', 2, second, '=', (second ** 2))
