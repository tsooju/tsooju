#chap02_test2.py



name = input('이름: ')
age = int(input('나이: '))
gender = input('성별 [남/여]: ')
height = float(input('키: '))
weight = float(input('몸무게: '))

# print(name,'은', age,'세', gender,'자이고', '키는', height, 'cm 몸무게는', weight, 'kg 입니다.')

# print 누르고 변수 값을 패치 할 곳에는 {}를 표시한다. 전체가 하나의 문장이다라고 표현할 수 있다.

print("{}은 {}세 {}자이고, 키는 {}cm 몸무게는 {}kg 입니다.".format(name, \
                                                     age, gender, height, weight)) # 헐신 좋은 방법이 된다.

# {안에 변수의 순서번호를 적어줄 수 있다는 것이다. 모든 컴푸터는 0 부터 시작한다. }

print("{0}은 {1}세 {2}자이고, 키는 {3}cm 몸무게는 {4}kg 입니다.".format(name, age, gender, height, weight))