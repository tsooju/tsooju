# chap03_builttype.py

# 파이선 내장자료형( built in type)확인용

# 파이선은 객체지향형 그크립트 언어이다.
# 자죠형은 (값의 종류) 객체와 레퍼런스로 관리됩. 그래서 클래스 int, 클래스 str 라고 표현한다는 뜻이다.
# 객체(object) :  클래스(class)로 만들어진 결과물(기억공간)이라고 한다. 변수인데 큰 번수라고 한다.
# 레퍼런스(reference) : 객체의 위칰(조소) 정보를 가진 주소변수다. 이너는 매핑이다.
#객체(변수)가 가지는 값은 실행될 때 동적할당(allocation)되도록 되어 있음.

# a # 변수 선언(번수 방이름 지어주는 것)만으로는 에어임. 자바는 가능함.
a = 1 # 반드시 값 기록이 되어야 변수 생성이 됨.
# 1은 정수이므로, 변수공간 a 의 type은 <class 'int'>라고 한다. 객체지향형이기 때문에 class 를 붙이는 것이다.
# 변수 생성시 메모리(ram)에 객체공간을 만들고, 객체 안에 1을 기록하고
# 만들어지 객체의 주로를 a 에 기록함.
# a 는 값을 가진 객체의 주소를 가진 레퍼런스 변수임.
# id 란 함수로 a 가진 주소(위치)를 찾을 수 있다. this is reference. it's like to oparation java. need
# need to inderstand.

print("a 가 참조하는  객체가 가진 값 : ", a)
print("a가 가진 위치정보 : ", id(a))

b = 1
print("b가 가진 위치(주소) : ", id(b)) # 1 전에 만들어졌기 때문에 같은 주소를 연결한드는 것이다. a와 b는 같은
# 객체를 (1)을 가지고 있다는 뜻이다. 파이선은 새로 할당하지 않다는 것이다.

# 파이선은 같은 값이 메모리에 객체로 존재하면, 새로 할당하지 않고
# 기존의 객체의 주소를 리턴함.
# a와 b 가 가진 주소가 같음.

a =  2 # <class 'int'> 객체 공간을 만들고, 그 안에 2를 기록하고
# 2가 기록된 객체공간의 주소를 a에 기록함.

print("a 가 참조하는  객체가 가진 값 : ", a) # 새로 생성되는 2를 새로운 주소로 욺길 것이다.
print("a가 가진 위치정보 : ", id(a))


print("b 가 참조하는  객체가 가진 값 : ", b)
print("b가 가진 위치정보 : ", id(b))

# 정수 : <class 'int'>, 양수, 0, 음수 tegsh too, 0, sondgoi too, 1씩 차이나는 수

num1 = 0
num2 = -11 # 음수 , sondgoi too

num3 = 24 # 양수 , tegsh too

print("num1 : ", num1, type(num1), id(num1))
print("num2 : ", num2, type(num2), id(num2))
print("num3 : ", num3, type(num3), id(num3))

# 정수 자료형 값 표현은 기본 10진수임. 10tiin butarhai gsn ug
# 파이썬에서도 코드 구문에 정수값 표현식 다른 진수들을 사용할 수 있음.
# 정수값 앞에 진수를 표시하는 접두어를 붙여주면 된다.
# 8진수(octal)는 숫자 앞에 0o(zero 오(영))을 표시함.
# 16진수(hex)는 숫자 앞에 0x(zero x), or(|) OX(대문자 ZERO X)표기함.
# 파이선에서는 2진수를 코드상에서 지공하고 사용할 수 있으면 다른 언어에서는  2진수를 사용할 수 없게 되어 있다.
# 2진수(bit)는 숫자 앞에 0b(zero b) 를 표기한다. (2로 나눈 나머지 값)
dnum = 12345 # 10진수(decimal)
bnum = 0b0111 # 2진수(bit)   2'2, 2'1, 2,0 = 7
onum = 0o12 # 8진수(octal)
xnum = 0xf5 # 16진수(hex)  f는 나머지 값 15를 뜻함.

print()
print()

# print() 함수로 출력시에는 정수는 10진수로 출력되도록 되어 있음.
print("dnum : ", dnum, type(dnum), id(dnum))
print("bnum : ", bnum, type(bnum), id(bnum))
print("onum : ", onum, type(onum), id(onum))
print("xnum : ", xnum, type(xnum), id(xnum))

# 코드상으로는 구별해서 쓰지만 메모리에서는 10진수롤 가록된다.

# 문자형태(str)로 되어 있는 숫자는 계산을 못한다. 게산할 수 있게 하려면 숫자(int(정수형문자), float(실수형문자))로 변경해야 한다.
snum = "789"

print("snum : ", snum, type(snum))

result = int(snum) + 2 # 원하는 결과는 791

# 해결
print("result : {}, {}\n".format(result, type(result)))

# 파이선에서는 정수 자료형 값의 범위 제한이 없음.

# C언어, C++은 int 값 범위가: -32768 ~ 32767 이 범위 숫자 밖에 못 다룬다.
# 자바의 int 값 범위가 : -2147683648 ~ 2147483647 이 범위 숫자 범위 내에서만 다룬다.
# 윗 숫자들을 외워놓아야 한다.

inum = 12999999999999999999999999999999999999999999999999999
print("inum : {}, {}\n".format(inum, type(inum)))


# 실수 자료형 : <class "float">
# 소숫점 아래 값을 취급하는 수
# 1.23(부동수소점형 표기 | 비과학용 표기, floating),
# 123 + e2 (과학용 표기, scientific)
# 과학용 표기의 + 는 오른족, - 는 왼쪽으로 소수점을 이동시킨다는 의미임.
# e제곱수는 자리이동 칸수를 의미함. 10의 제곱수를 의미함.
# + e3 은 * 10의 3제곱, -e3 은 나누기(/) 10의 3제곱을 의미함.

fnum = 25e-3 # 0.0025 된다는 뜻
print(f"fnum : ", {fnum}, {type(fnum)}) # print() 함숫는 기본 floating 표기함.

# 지수형의 + 표기는 생략되기도 함.
fnum = 3e5 # 3000.0
print(f"fnum : ", {fnum}, {type(fnum)})





