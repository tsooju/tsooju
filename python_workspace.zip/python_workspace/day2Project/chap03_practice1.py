# chap03_practice1

# 문자자료형 실습문제
# 문자에  random ***  3  = randomrandomrandom 나온다

member_name = input('회원이름 :')
member_id = input('회원 아이디 :')
member_passwd = input('패스워드 :')
age = int(input('나이 :'))
height = float(input('키 :'))

member_passwd = member_passwd[0:4] + '*' * (len(member_passwd) - 4)
print('{} 회원의 아이디는 {}이고, 암호는 {}입니다. '
      '나이는 {}세이고, 키는 {:0.1f}cm 입니다.'.format(member_name, member_id,
                                       member_passwd, age, height))

# len() 함수는 문자열의 문자 개수를 반환하는 내장함수이다.






