# chap03_str.py

# 파이선에서 문자열 다루기

# 파이선에서 문자열(str)은 시퀀스(sequence : 순차자료형)로 취급됨.

# 시퀸스 자료형은 값이 순번(인덱스, index)이 매겨진다. 0부터 시작됨.

#  문자 선택 연산자 (인덱싱) : 문자별수[인덱스순번]

ss = 'Hi,-python'
print('첫번째 글자: ', ss[0])

print('첫번째 글자:(인덱스 4) ', ss[4])

print('뒤에서 첫번째 글자: ', ss[-1])

# 문자열 범위 선택 연산자 (슬라이싱) : 문자열값 부분 추출시 사용
# 문자변수[시작인덱스: 끝인덱스 -1:간격]

print(ss[0:3]) # 0,1,2번째 3글자 추출
print(ss[0:5:2])


# 슬라싱을 이용새허 문자열을 역순으로 정렬
print(ss)
print(ss[::-1]) # 역순으로 정력된다는 뜻(간격을 음수로 지정함)

# 슬라이싱과 연결연산 혼합 사용 가능합.
n1 = 'abcdef'
n2 = '12345'
n3 = n1[0:3] + n2[1:]
print(n3)

# 문자처리 내장함수 :
# upper(), lower() : 영문자일때 대/소문자로 변환함수

tt = 'apple'
print(tt)

# 파이선에서는 기록된 문자값은 변경할 수 없음.
# tt[1] = 'b'  => 문자는 변경 불가능하다. error
# 해결하는 방법이 있다: 제공되는 관련 함수를 사용하면 됨.
print(tt.upper()) # tt 변수가 대문자로 변환된다.

tt2 = 'BANANA'
print(tt2.lower())

# swapcase(), capitalize()
tt3 = 'tEst stR pyTHon'
print(tt3.swapcase()) # 대문자는 소문자되고, 소문자는 대문자로 변환됨.
print(tt3.capitalize()) # 문장의 첫 글자를 대문자로 변환, 나머지는 소문자로 변환한다.

# title() : 각 단어의 첫글자를 대문자로 변환
print(tt3.title())

# strip()m lstrip(), rstrip()  - 공백잡는 함수다.

tt4  = '         test str value           '
print('|', tt4, '|', sep='')  # sep함수로 값들 사이에 공백을 없애는 것이다.

print('|', tt4.strip(), '|', sep='')    # strip은 문자 앞뒤의  공백을 제거한다.
print('|', tt4.lstrip(), '|', sep='')    # lstrip은 문자 왼쪽  공백을 제거한다.
print('|', tt4.rstrip(), '|', sep='')    # rstrip은 문자 오른쪽  공백을 제거한다.

# split(), splitlines()

tt5 = 'abc-deg-ghi-j'
print('tt5 : ', tt5)
print(tt5.split("-"))  # split은 문자를 조각 조각 분리한다.['abc', 'deg', 'ghi', 'j'] 형식된다.
#  여러 개의 문자들로 분리됨 => 리스트 형식 됨.

# splitlines() : 줄(line) 단위로 분리해서 리스트를 리턴한다.
tt6 = '''python
java
javascript
c++'''
print(tt6)

print(tt6.splitlines()) # ['python', 'java', 'javascript', 'c++']


# indec(), find() : 글자 위치(순번: 인덱스) 조회
print(tt5.index('e')) # 문자열 안에 있는 'e' 문자의 위치 조회된다.
# 만약 문자 안에 없는 문자를 조회하면 에러 출력된다.

# print(tt5.index('k'))
print(tt5.find('e'))  # 찾아낸 문자의 위치를 리턴

print(tt5.find('k'))  # 없는 문자 조회시에는 -1 죄회된다.

# 이외의 다른 문자 관련 함수 조회하려면 다음과 같다.
print(dir(str))


# 문자열에 포맷(forma)을 적용하야 코드 작성하는 방법:
# 문자역 값 사이에 다른 종류의 값이나 변구를 적용하려고 할 때 이용

#  정수숫자의 대쉬머리를 d로 표시한다.문자열 사이에 포맷을 사용할 수 있는 예다.

amount = int(input('갯수 입력 : '))
st = '나는 사과를 %d 개 주문하였음' %amount
print(st)

# 정수 10진수 (decimal) : %d
# 문자열 (string) : %s
# 실수형 숫자 (float) : %f

product_name = input('주문할 상품명 : ')
price = int(input('제품의 단가 :'))

st2 = '상품명은 %s 이고, 기본 단가는 %d 이다' %(product_name, price)
print(st2)
























# 군집 자료형 (str - 문자열, list - 리스트, tuple - 튜플, dict, set - 집합)

# 매핑방식을 알기
# 저장개수를 여러개를 저장할 때 컨테이너 방식라고 한다.

# 객체 ?
# 래퍼런스(reference)

# a = 'ganaa'
# print(a)
#
# d = "\' ganaa \""
# print(d)
#
#
# # \n enter key 역할을 해준다는 것이다.
#
# # 글자 이루워질 때 인댁스 즉 숫자가 주어진다
# # 예: 안녕하세요 하면 안 -0, 녕 - 1, 하 - 2, 세 - 3, 요 - 4라고 숫자가 주어진다는 뜻이다.
# # 또는 거구로 숫자를 줄 수 있다.
#
# a = '안녕하세요'
# print(a[0])
# print(a[1:3])
# print(a[0:5:2]) # 0 에서 5번까지 하되 뒤 2란 것은 2칸식 띄어서 한다는 뜻이다.



