# 파이썬 연습 2일차 테스트 프로젝트

# 함수 만드는 규칙
def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.(파이썬에서 메인으로 구동 되는 구조라 함부로 만질 수 없다.)
# 프로그램 언어마다 메인 시작하는 모양이 약한 다르다. 자바는 딱 하나만 만들어났다. C 언어는 4개를 만들었는데 선택권들 줬다.
# microsoft는 자바한테 밀려서 만든 언어는 C 언어다. 자바는 프로그램 만드는데에서는 아주 적합하다.
# 파이썬에서 main 구동시키는 방법:
if __name__ == '__main__':
    print_hi('Pycharm')

# See PyCharm help at https://www.jetbrains.com/help/pycharm/

list = list(range(100))
print(list)
print(list[12:50])
print(list[2:5])
print(list[-1:])

item = "banana"
item2 = "apple"
item_c = item.center(100)
print(item_c)
print(item.ljust(100))
print(item.rjust(100))

a = set(["banana", "apple"])
b = set(["apple", "orange"])

print(a & b)
print(a - b)
print(b - a)