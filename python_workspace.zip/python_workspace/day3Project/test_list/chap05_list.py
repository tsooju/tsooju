# chap05_list.py
# 파이선이 제공하는 리스트 관력 함수 test

lst = [1, 3.5, "list", True, 20, ["a", "b", "c"]]
print(f"before : {lst}")

# append()  : 뒤에 추가
# list변수.append(추가할 값)

lst.append(456)
print(f"after append : {lst}")
print(f"length : {len(lst)}")

# remove() : 지정한 데이터 제거함 : 갯수 줄어듦
# 리스트변수.remove(제거할 값)
lst.remove(20)
print(f"after remove : {lst}")


# 참고로 같은 값이 여러 개 저장되어 있는 리스트인 경우.

lst_1 = [1, 1, 2, 2, 1, 3]
print(f"before remove : {lst_1}")
print(f"length : {len(lst_1)}")
lst_1.remove(1)
print(f"after remove : {lst_1}")  # 앞에서부터 검색해서 첫번째로 만나는 해당값만 삭제함.
print(f"length : {len(lst_1)}")

# insert() : 리스트 안의 원하는 위치에 값을 추가할
# 리스트번수.insert(추가할 인덱스, 추가할 값)

print(f"before insert : {lst}")
print(f"length : {len(lst)}")

lst.insert(1, "추가확인")  # 기존 위치의 데이터들은 뒤로 한칸씩 밀려남.
print(f"after insert: {lst}")
print(f"length : {len(lst)}")


# pop() : 인덱스 위치의 값을 꺼내면서 제거
# 방법1 : 리스트변수.pop() : 마지막 인덱스 위치의 값 꺼내면서 제거
# 방법2 : 리스트번수.pop(index) : 해당 인텍스 위치의 값 꺼내면서 제거

lst.pop()
print(f"before pop : {lst}")
print(f"length : {len(lst)}")

lst.pop(3)
print(f"after pop : {lst}")
print(f"length : {len(lst)}")

 # extend() : 기존 리스트 뒤에 다른 리스트를 추가 함으로 리스트를 확장함.
 # 리스트번수1.extend(연장할 리스트)(append와 비슷하고 리스트를 추라하므오 다름.)

lst.extend(lst_1)
print(f"after extend : {lst}")
print(f"length : {len(lst)}")

# reverse() :리스트의 저장순서를 반대로 뒤집기함.
# 리스트번수.reverse()
lst.reverse()
print(f"after reverse : {lst}")  # 순서만 변경함

# sort() : 리스트의 저장값들을 오름차순정력 처리함. sort할 수 있는 리스트와 없는 리스트 있디.
# 한가지 종류의 값들로만 저장되어 있을 때 사용할 수 있다. 알고리즘의 중요한 것은 정력하는 것이다.

# lst.sort() # 여러 종류의 값들은 크냐 작으냐에 대한 비교연산 못 함. error

lst_int = [6,5,4,8,4,5,7,4,5,7,8, 54, 656, 54, 5]
print(f"before sort : {lst_int}")
lst_int.sort()
print(f"after sort : {lst_int}")
lst_int.sort(reverse = True) # 내림차순정력 (큰값에서 작은값 순으로)
print(f"after sort(descending) : {lst_int}")

lst_float = [5.3, 6.2, 6563.5, 65.54, 6.5, 9.8, 10.5]
print(f"before sort : {lst_float}")
lst_float.sort()
print(f"after sort : {lst_float}")
lst_float.sort(reverse = True) # 내림차순정력 (큰값에서 작은값 순으로)
print(f"after sort(descending) : {lst_float}")

lst_str = ["orange", "apple", "melon", "banana", "kiwi"]   # alphabet 순으로 정력한다.
print(f"before sort : {lst_str}")
lst_str.sort()
print(f"after sort : {lst_str}")
lst_str.sort(reverse = True) # 내림차순정력 (큰값에서 작은값 순으로)
print(f"after sort(descending) : {lst_str}")

slt_str_kr = ["자바", "파이선", "c언어", "리앤트"]
print(f"before sort : {slt_str_kr}")
slt_str_kr.sort()
print(f"after sort : {slt_str_kr}")
slt_str_kr.sort(reverse = True) # 내림차순정력 (큰값에서 작은값 순으로)
print(f"after sort(descending) : {slt_str_kr}")

# count() : 리스트에 저장된 동일한 값의 갯수 조회
# 리스트변수.count(찾을 값)

print(f"lst : {lst}")
print(f"lst 에 저장된 정수 1의 갯수 조회 : {lst.count(2)}")

