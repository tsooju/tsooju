# mission2.py
# list practice

# 입력내용:
        # 국어 접수 : 78.5(kor : float)
        # 영어 접수 : 88.7(eng : float)
        # 수학 접수 : 93.5(mat : float)

# 처리 내용 :
        # 3명의 학생 점수를 입력 받음
        # 학생별 접수는 각 리스트에 저장한 다음, [국어, 영어, 수학, 총점, 평균]
        # 각 학생 점수를 리스트 (sungjuk_list)에 순서대로 저장 처리함
        # [[국어, 영어, 수학, 총점, 평균], [국어, 영어, 수학, 총점, 평균], [국어, 영어, 수학, 총점, 평균]]
        # 3명의 점수의 총합(total_score : int)과 전체평균(average_score : float)를 계산하시오.

# 처리 내용 :
        # 리스트에 저장된 값들을 출력함
        # 국어, 영어, 수학, 총, 평균, 순러로, 출력,
        # -> 점수는 소수점아래 둘째자리까지 표시
        # -> format() 사용함
        # 전체 총점과 전체 평균을 출력하시요.



list_1 = []
list_1.append(float(input("1번학생 국어점수 : ")))
list_1.append(float(input("1번학생 영어점수 : ")))
list_1.append(float(input("1번학생 수학점수 : ")))
list_1.append(list_1[0]+list_1[1]+list_1[2])
list_1.append(list_1[3] / 3.0)




list_2 = []
list_2.append(float(input("2번학생 국어점수 : ")))
list_2.append(float(input("2번학생 영어점수 : ")))
list_2.append(float(input("2번학생 수학점수 : ")))

list_3 = []
list_3.append(float(input("3번학생 국어점수 : ")))
list_3.append(float(input("3번학생 영어점수 : ")))
list_3.append(float(input("3번학생 수학점수 : ")))

print("1번학생의 총점 : ", int(len(list_1)))
# print("2번학생의 총점 : ", int(list_2[0+1+2]))
# print("2번학생의 총점 : ", int(list_3[0+1+2]))