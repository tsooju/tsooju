# This is a start Project script.
# day4Project 시작 시키는 스크립트
# import mission.list_review
# 모듁명이 길거나 복잡하면 줄임말을 지정할 수 있음.
# import 모듁명 as 줄임말

# import test_set.set_sample as ts  #(as)로 긴 말을 줄일 수 있다.
# import test_dict.dict_sample as td
# import mission.dict_review as mdr
# import mission.dict_review2 as md2

# Run 버튼 클릭 | Shift + F10 누르면 실행됨.
# if __name__ == '__main__':  # 여기서 main은 파일명이다.
    # test_set.set_sample.test1()
    # ts.test1()
    # ts.test2()
    # ts.test3()
    # ts.test4()
    # ts.test5()
    # ts.test6()
    # ts.test7()
    # td.test1()
    # td.test2()
    # td.test3()
    # td.test4()
    # td.test5()
    # td.test6()
    # td.test7()
    # td.test8()
    # td.test9()
    # mdr.dictfunc()
    # md2.dictfunc1()
    # md2.dictfunc1()




    # mission.list_review.func()

# 모듁 : 함수를 가지고 있는 파이선 파일.
# 다른 파이선 파일에서 모듈이 가진 함수를 사용하려면
# import 문을 사용해서 임포트 선언하면 됨.
# import 파일명 (같은 디렉토리에 있는 파일일 때)
# import 디렉토리명 : 파일명

# import list_review 이렇게 만 하면 안된다.
  # 미션 안에 있는 list_review창을 열어준다.
# import 사용을 하면 어디서든 파일을 가지고 올 수 있다. 반드시 이름 붙여주어야 한다. 그거는 def 함수다.

    # import한 module(file)이 가진 함수를 사용(실행)하려면, (:) 있으면 콜론 다음 부터 항상 드려쓰기 한다. 뭔가 작동 됭때란 뜻
    # 모듈명.함수명()


import test_logic.chap07_conditional as logic
if __name__ == '__main__':
    # logic.func_bool()
    # logic.func_bool2()
    # logic.func_compare()
    logic.func_logical()
