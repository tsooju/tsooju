# mission\dict_review.py
# 사전 자료형 복습문제

def dictfunc():

    student_dict = {}
    student_dict["name"] = input("이름 : ")
    student_dict["grade"] = int(input("학년 : "))
    student_dict["s_class"] = int(input("반 : "))
    student_dict["s_no"] = int(input("번호 : "))
    student_dict["score"] = float(input("점수 : "))
    print("{}학년 {}반 {}번 {}의 점수는 {:0.2f}입니다.".format(student_dict.get("grade"),
                                                    student_dict.get("s_class"), student_dict.get("s_no"),
                                                    student_dict.get("name"), student_dict.get("score")))





