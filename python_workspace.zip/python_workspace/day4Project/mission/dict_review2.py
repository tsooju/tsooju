# mission\dict_review2.py
# dict 자료형 복습문제 2

def dictfunc1():

    sno = int(input("번호 : "))
    sname = input("이름 : ")
    kor = int(input("국어 : "))
    eng = int(input("영어 : "))
    mat = int(input("수학 : "))

    tot = kor + eng + mat
    avr = tot  / 3

    sungjuk_dict = {sno: [sname, kor, eng, mat]}


    print("{}번 {}의 총점은 {}점, 평균은 {}점".format(sno, sungjuk_dict[snu][0],
                                            sungjuk_dict[snu][4], sungjuk_dict[snu][5]))
    print("국어 : {}, 영어 : {}, 수학 : {}점입니다.".format(sungjuk_list[1], sungjuk_list[3], sungjuk_list[4]))




