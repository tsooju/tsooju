# list_review.py
# list 자료형 복습문제

# 번호 : 12 (son :int)
# 이름  황지니 (sname : str)
# 국어 : 85 (kor : int)
# 영어 : 85 (eng : int)
# 수학 : 85 (mat : int)

# 처리내용 :
#         입력은 값은 리스트 (sungjuk_list)
#         index 0 : sno,  index 1 : sname,  index 2 : kor,  index 3 : eng,
#         index 4 : mat,  index 5 : 3과목총점(int),  index 6 : 3과목의 평균(float)


def func():
    # 모든 함수는 두이에 괄호를 입력한다. 함수 안에 있는 변수는 매개 변수라고 있다. 그리고 뒤에 꼭 : 붙여준다. 함수 안에서 사용할
    # text는 꼭 드려쓰기를 한다. 전체 문자를 클릭 해서 Tab(키보드)에서 클릭한다.


    sungjuk_list = [] # sno, sname, kor , eng , mat , total_scores  , average_scores

    scores = []

    scores.append(int(input("번 : "))) #0
    scores.append((input("이름 : "))) #1
    scores.append(int(input("국어 : "))) #2
    scores.append(int(input("영어 : "))) #3
    scores.append(int(input("수학 : "))) #4

    total_scores = scores[2] + scores[3] + scores[4]
    average_scores = total_scores / 3.0
    sungjuk_list.append(total_scores)
    sungjuk_list.append(average_scores)


    print("{}번 {}의 총점은 {}점, 평균은 {:0.2f}점".format(scores[0], scores[1], sungjuk_list[0], sungjuk_list[1]))
    print("국어 : {}점, 영어 : {}점, 수학 : {}점입니다.".format(scores[2], scores[3], scores[4]))



# 파이선에서는 함수를 적을 때 먼저 def라고 적는다. 숫자로 하면 안되고, _ 바만 사용 가능.