# 경로 표시 : test_logic\\chap07_conditional.py   => \는 \\(2개)로
# 경로 표시 : test_logic/chap07_conditional/py    => /는 /(1개)로
# 모듈 표현 : test_logic.chap07_conditional

# bool 자료형 확인
def func_bool():
    flag = True
    print("flag : ", flag, type(flag))

    flaf = False
    print("flag : ", flag, type(flag))

    # 파이선에서 대소문자를 구분함
    # flag = true # NameError

# bool() 함수 사용 : bool 형으로 자료의 논리상태를 확인할 때 사용함.
# 리턴되는 결과값은 True | False

def func_bool2():
    print("결과 : ", bool("abcd"))
    print("결과 : ", bool(""))

    #  값이 저장되어 있는지, 비어 있는지 확인하는 용도로 사용할 수 있음.
    print(bool({'a': 1, "b": 2}))  # True
    print(bool({}))  # False

    print(bool([1, 2, 3, 4]))  # 값이 있으면 True
    print(bool([]))   # 값이 없으면 False

    print(bool((1, 2, 3, 4)))  # 값이 있으면 True
    print(bool(()))  # 값이 없으면 False

    print(bool(23))   # 정수 있으면 True, 파이선은 0을 제외한 모든 겂을 True로 인식한다.
    print(bool(0))    #  False


# 비교(관계) 연잔자 확인
# 2개의 값을 가지고 크냐(>, 초과) or 작으냐(<, 미만),
# 같으냐(==) or 같지 않으냐(!=), 크거나 같으냐(>=, 이상), 작거나 같으냐(<=, 이하)
# 윗 것을 이항 연산자에 해당된다고 말한다 : 값1 연산자 값2

def func_compare():
    print("1 == 1 :", 1 == 1) # True
    print("1 == 2 :", 1 == 2) # False

    print("1>0 : ", 1 > 0)  # True
    print("1 < 2 : ", 1 < 2) # True
    print("1 >= 1 : ", 1 >= 1)  # 2중 하나가 맞으면 True
    print("1 != 0 : ", 1 != 0)  # True

# 논리 연산자 : 논리값(True, False)을 계산에 사용하는 연산자
# and, or, not
def func_logical():
    a = 1
    b = 2

    # 연산자들은 우선순위가 있디. 왼쪽부터 실행 된다. 그래서 a 부터 실행된다는 것이다.(1.a, 2.b. 3.and실행된다)
    print(a > 0 and b > 1)  # True and True 결과는 True
    print(a == 0 or b != 1)    # a 부터진행하고, b b계산하고 or 실행도니다. 결과 False or True 면 => True 리턴한다.\

    # and와 or 연잔자의 특징이 있다.
    # and 연산자 특징 :
    # 앞 and 뒤 : 앞이 False이면 뒤를 실행 안함. 뒤가 뭐든 상관 없이 실행 안되며 거짓이 되는 것이다.
    # 앞이 True 이면 뒤를 계산 실행함. 모든 프로그래밍 언어가 이 방식으로 실행된다.
    print("a" and "b")   # 여기서 앞이 True라서 뒤를 출력 한다. a를 실행해서 b를 실행해주세요 란 말이다.
    print("" and "b") # 앞이 False 이므로 뒤를 실행 안 함.

    # or 연산자의 특징 :
    # 앞 or 뒤 ; 둘중의 1라도 True면 True로 실행한다.
    print("a" or "b") # 앞이 true 이므로 뒤 실행 안함. "a" 출력
    print("" or "b")


















